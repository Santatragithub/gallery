export interface Faq {
  question: string
  answer: string
}

export interface Tutorial {
  title: string
  url: string
}

export interface UserCreate {
  name: string
  email: string
  password: string
}

export interface UserLogin {
  email: string
  password: string
}
