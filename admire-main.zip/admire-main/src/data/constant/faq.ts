import { Faq, Tutorial } from '../type/type';

export const faqs: Array<Faq> = [
  {
    question: 'What’s an NFT ?',
    answer: `On admire, “NFT” refers to any token you can collect.
    Whether the work is unique (1/1) or in several editions.`,
  },
  {
    question: 'Why do the most renown artists sell on Admire ?',
    answer: `Because admire works only with the world’s most prestigious galleries,
    the artworks offered come from the most renowned artists.`,
  },
  {
    question: 'Who handles the creation of an NFT ?',
    answer: `On admire, an artist’s NFT is alway tokenized (minted) through
    the artist’s blockchain address.This insures the authenticity and the origin of the artwork.`,
  },
  {
    question: 'Why should I use admire rather than another platform ?',
    answer: `Because the most prestigious artists and the most valuable artworks are only on admire.
     Also, the platform runs on the Tezos Blockchain which, as apposed to other Blockchains,
    allows for low transactions fees, is never congested and is regularly updated.`,
  },
  {
    question: 'Why are KYCs mandatory to purchase NFTs on admire?',
    answer: `At admire, we respect and anticipate the laws in force.
    This will allow our buyers to be able to sell their NFTs on all other platforms
    and consequently allow the works of artists to retain their value over time.`,
  },
  {
    question: 'Which company handles the KYCs ?',
    answer: `Admire entrusts Onfido For KYC checks.This company handles tier-one clients such as Revolut,
    Orange, Remity, Bunq, Wirex, Bitstamp, Nickel…`,
  },
  {
    question: 'How do vendors receive their payments ? Are purchases secure ?',
    answer: `Purchases are made directly from the seller to the buyer via a smart contract that we have
    developed. The seller therefore receives the payment on his Tezos wallet in real time.`,
  },
  {
    question: 'I don’t hold Tezos, what should I do in order to use the platform ?',
    answer: `You can easily convert your euros/dollars into Tezos (XTZ) on exchanges such as Binance,
    Kucoin, Kraken… These platforms also allow you to convert your Tezos back to traditional
    currencies (euro, dollars…)`,
  },
  {
    question: 'What is admire’s added value for galleries ?',
    answer: `Admire allows galleries to be part of a market from which they were previously excluded. Selling
    on admire allows them to reach an audience that they didn't have access to before.`,
  },
  {
    question : 'How can we be insured that on-sale NFTs will be bought ?',
    answer: `Our marketing team makes every effort to ensure that our site is consulted by the greatest number
    of collectors.
    However, as they would for any physical work, we strongly advise galleries and artists to share the
    NFT sales page on social medias, newsletters etc.`
  },
  {
    question : 'Do the on-sale NFTs have to be unique (1/1) or multiple editions ?',
    answer: `It's the artist's choice. At the time of the tokenization,
    he will choose the number of editions he wishes to create for his work.`
  },
  {
    question : 'How to set the NFT’s price on primary market?',
    answer: `As with any physical work it depends on the market value of the artist.
    The decision is up to the artist and his gallery.`
  },
  {
    question : 'Can the NFTs on-sale in multiple editions be different or do they have to be identical ?',
    answer: `When tokenizing an artwork, the artist chooses the number of editions he wishes to create for his
    work. Therefore, whether the NFT is unique (1/1) or multiple editions, the work will be identical.`
  },
  {
    question : 'Are the NFTs numbered ?',
    answer: 'NFTs are not numbered. Only the total number of editions of the artwork appears.'
  },
  {
    question : 'Who choses whom can sell on this platform ?',
    answer: `The admire team curates the most prestigious galleries on the planet.
    On Admire, the galleries can whitelist the addresses of their artists in order to give them
    authorization to create tokens via the admire smart contract.`
  },
  {
    question : 'What are the marketing tools that will be deployed to sell the artists’ NFTs quickly ?',
    answer: 'What are the marketing tools that will be deployed to sell the artists’ NFTs quickly ?'
  },
  {
    question: 'I just bought an NFT, can I resell it?',
    answer: `Any user who has passed the verification can list an NFT previously purchased on admire, at any
    time and at any price.`
  },
  {
    question: 'Are royalties paid to the artist even if his works are sold by a gallery?',
    answer:'Yes, a 2% royalty is automatically sent to the artist’s wallet each time one of his work is sold.'
  },
  {
    question: 'Do I need cryptocurrencies to buy items on admire?',
    answer:`Yes, on admire all transactions use XTZ which is the cryptocurrency of the Tezos blockchain. You
    can easily buy and sell your XTZ on exchanges such as Binance, Kucoin, Kraken…`
  },
  {
    question: 'What fees do you charge?',
    answer: `Admire automatically takes a 5% fee on each transaction.
    Artists automatically receive a 2% royalty each time one of their works is sold.`,
  }
]

export const tutorials: Array<Tutorial> = [
  {
    title: 'How to tokenize an artwork?',
    url: 'https://www.youtube.com/embed/k3_tw44QsZQ?rel=0',
  },
  {
    title: 'How to buy an NFT?',
    url: 'https://www.youtube.com/embed/k3_tw44QsZQ?rel=0',
  },
  {
    title: 'How to sell an NFT?',
    url: 'https://www.youtube.com/embed/k3_tw44QsZQ?rel=0',
  },
  {
    title: 'How to burn an NFT?**',
    url: 'https://www.youtube.com/embed/k3_tw44QsZQ?rel=0',
  },
  {
    title: 'How to create a wallet?',
    url: 'https://www.youtube.com/embed/k3_tw44QsZQ?rel=0',
  },
  {
    title:
      'How to buy and sell XTZ (the tezos blockchain native cryptocurrency)',
    url: 'https://www.youtube.com/embed/k3_tw44QsZQ?rel=0',
  },
];
