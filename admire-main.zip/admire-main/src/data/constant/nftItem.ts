export  const Item = [
  {
    url: 'https://cdn.quasar.dev/img/mountains.jpg',
    nftName: 'Lorem Ipsum Name',
    artistName: 'nomdelartiste',
    number: '1/250',
    price: '0.784'
  },
  {
    url: 'https://cdn.quasar.dev/img/parallax2.jpg',
    nftName: 'Lorem Ipsum Name',
    artistName: 'nomdelartiste',
    number: '1/250',
    price: '0.784'
  },
  {
    url: 'https://cdn.quasar.dev/img/mountains.jpg',
    nftName: 'string',
    artistName: 'Lorem Ipsum Name',
    number: '1/250',
    price: '0.784'
  },
  {
    url: 'https://cdn.quasar.dev/img/parallax2.jpg',
    nftName: 'Lorem Ipsum Name',
    artistName: 'nomdelartiste',
    number: '1/250',
    price: '0.784'
  },

]
