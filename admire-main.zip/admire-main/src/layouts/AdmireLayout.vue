<template>
  <q-layout view="hHh LpR fFf">
    <HeaderComponentVue @toggle-drawer="drawerLeft = !drawerLeft"/>
    <LeftDrawerComponent v-model="drawerLeft" />
    <q-page-container>
      <router-view />
    </q-page-container>
    <FooterComponent />
  </q-layout>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import FooterComponent from 'src/components/FooterComponent.vue'
import HeaderComponentVue from 'src/components/HeaderComponent.vue'
import LeftDrawerComponent from 'src/components/LeftDrawerComponent.vue'
export default defineComponent({
  name: 'AdmireLayout',
  components: {FooterComponent,HeaderComponentVue,LeftDrawerComponent},
  setup () {
    return {
      drawerLeft: ref(false)
    }
  }
})
</script>

<style scoped>

</style>
