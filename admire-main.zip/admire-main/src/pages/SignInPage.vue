<template>
  <div class="adminre-container-mid q-mx-auto">
    <div class="row justify-center">
     <h3 class="title text-weight-bold">Sign in</h3>
     <h3 class="or q-mx-md text-weight-bold">or</h3>
     <h3 class="title text-weight-bold">Create Account</h3>
    </div>

    <p class="description text-center">
      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
      Laborum obcaecati dignissimos quae quo ad iste ipsum officiis eniti asperiores sit.
    </p>

    <div class="row column content-center wrap-button">
      <div class="q-mb-md">
        <ad-button textButton="TEZOS" @click="tezos" />
      </div>
      <div>
        <ad-button textButton="EMAIL" @click="router.push('/sign-in-email')"/>
      </div>
    </div>

  </div>

</template>
<script setup lang="ts">
import AdButton from 'src/components/AdmButtonPrim.vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const tezos = () => {
  console.log('test')
}
</script>
<style lang="scss" scoped>

.title {
  font-family: $Crimson_Pro;
  letter-spacing: 0px;
  opacity: 1;
  color: $--unnamed-color-000b1e;
}
.or {
  font-family: $Crimson_Pro;
  letter-spacing: 0px;
  opacity: 1;
  color: $--unnamed-color-777777;
}
.description {
  font-family: $Helvetica_Neue_LT;
  letter-spacing: 0px;
  color: $--unnamed-color-000000;
  opacity: 0.7;
  position: relative;
  bottom: 40px;
  width: 50%;
  left: 245px;
}

.wrap-button {
  height: 200px;
  width: fit-content;
  margin: auto;
  padding: 56px 120px;
  background:#FAFAFA 0% 0% no-repeat padding-box;
  border-radius: 20px;
  opacity: 1;
}

@media screen {

}
</style>
