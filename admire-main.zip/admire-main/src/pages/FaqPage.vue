<template>
  <div class="adminre-container-mid container">
    <h4 class="title text-center text-weight-bolder">FAQ</h4>
    <div v-for="({question, answer}, index) in faqs" :key="index">
      <q-card class="my-card q-px-md q-my-lg">
        <q-card-section>
          <div class="question text-h6 text-weight-bold text-left">{{ question }}</div>
          <div class="answer text-subtitle2 text-justify">{{ answer}}</div>
        </q-card-section>
      </q-card>
    </div>
    <h4 class="title text-center text-weight-bolder">Tutorials</h4>
    <div class="accordion" v-for="({title, url}, index) in tutorials" :key="index">
        <q-expansion-item
          :label="title"
            class="q-my-md"
        >
            <q-card>
              <q-card-section>
               <q-video :src="url" :ratio="16/9"/>
              </q-card-section>
            </q-card>
        </q-expansion-item>
    </div>

  </div>
</template>

<script lang="ts" setup>
import { faqs } from '../data/constant/faq'
import { tutorials } from '../data/constant/faq'


</script>

<style lang="scss" scoped>
.container {
  max-width: 750px;
  margin: auto;

  .title {
    font-family:$Crimson_Pro;
    letter-spacing: 0px;
    color: $--unnamed-color-000b1e;
  }

  .my-card {
    width: 100%;

    .question {
      font-family: $Helvetica_Neue_LT;
    }
    .answer {
      font-family: $Helvetica_Neue_LT;
      letter-spacing: 0px;
      color: $--unnamed-color-777777;
    }

  }

  .accordion {
    width: 100%;
    padding-inline: 25px;
    .q-expansion-item {
      background: $--unnamed-color-fafafa 0% 0% no-repeat padding-box;
      border: 1px solid #DEDEDE;
      text-align: left;
      font-family: $Helvetica_Neue_LT;
      font-style: normal;
      font-size: 20px;
      font-weight: 550;
      letter-spacing: 0px;
      color: $--unnamed-color-000000;
    }

  }

  .accordion :deep(.q-expansion-item--expanded) {
    background: $--unnamed-color-000000;
    color: #fff
  }
}
</style>
