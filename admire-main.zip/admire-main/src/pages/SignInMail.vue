<template>
  <div class="adminre-container-mid q-mx-auto">
    <div class="row justify-center">
     <h3 class="title text-weight-bold">Sign in</h3>
     <h3 class="or q-mx-md text-weight-bold">or</h3>
     <h3 class="title text-weight-bold"> Create Account with an email adress</h3>
    </div>

    <p class="description text-center">
      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
      Laborum obcaecati dignissimos quae quo ad iste ipsum officiis eniti asperiores sit.
    </p>

    <div class="row column content-center wrap-button">
      <div class="q-mb-md">
        <ad-button class="create" textButton="CREATE ACCOUNT" @click="router.push('/sign-up')" />
      </div>
      <div>
        <ad-button class="create" textButton="SIGN IN" @click="router.push('/login')"/>
      </div>
    </div>

  </div>

</template>
<script setup lang="ts">
import AdButton from 'src/components/AdmButtonPrim.vue'
import { useRouter } from 'vue-router'

const router = useRouter()

</script>
<style lang="scss" scoped>

.title {
  font-family: $Crimson_Pro;
  letter-spacing: 0px;
  opacity: 1;
  color: $--unnamed-color-000b1e;
}
.or {
  font-family: $Crimson_Pro;
  letter-spacing: 0px;
  opacity: 1;
  color: $--unnamed-color-777777;
}
.description {
  font-family: $Helvetica_Neue_LT;
  letter-spacing: 0px;
  color: $--unnamed-color-000000;
  opacity: 0.7;
  position: relative;
  bottom: 40px;
  width: 50%;
  left: 245px;
}

.wrap-button {
  height: 180px;
  width: 45%;
  margin: auto;
  padding: 45px 100px;
  background:$--unnamed-color-fafafa 0% 0% no-repeat padding-box;
  border-radius: 20px;
  opacity: 1;
  .create:deep(.q-btn__content ) {
    font-size: 12px;
  }
}

@media screen {

}
</style>
