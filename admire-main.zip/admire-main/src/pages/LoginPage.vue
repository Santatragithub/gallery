<template>
  <div class="adminre-container-mid q-mx-auto">
    <div class="head">
      <h4 class="title text-weight-bold text-center">Login</h4>
    </div>
    <div class="form q-mx-xl">
      <div  class="q-my-lg">
        <label class="label text-weight-bolder">Email</label>
        <q-input
          v-model="email"
          outlined type="email"
          :dense="true"
        />
      </div>
      <div  class="q-my-lg">
        <label class="label text-weight-bolder">Password</label>
        <q-input
          v-model="password"
          outlined
          type="password"
          :dense="true"
         />
      </div>
      <div class="wrap-button row justify-center">
        <div class="q-mb-md">
          <ad-button textButton="LOGIN" @click="login" />
        </div>
      </div>

    </div>

  </div>

</template>
<script setup lang="ts">
import { reactive, toRefs } from 'vue'
import { useRouter } from 'vue-router'

import AdButton from 'src/components/AdmButtonPrim.vue'
import { UserLogin } from '../data/type/type'

const router = useRouter()
const data = reactive<UserLogin>({ email: '', password: '' })
const { email, password } = toRefs(data)

const login = () => {
  console.log('-------->data', data)
  router.push('/')
}
</script>
<style lang="scss" scoped>
.title {
  font-family: $Crimson_Pro;
  letter-spacing: 0px;
  opacity: 1;
  color: $--unnamed-color-000b1e;
}
.description {
  font-family: $Helvetica_Neue_LT;
  letter-spacing: 0px;
  color: $--unnamed-color-000000;
  opacity: 0.7;
  position: relative;
  bottom: 40px;
  width: 50%;
  left: 245px;
}

.form {
  width: 460px;
  height: 300px;
  margin: auto;
  padding: 10px 30px;
  background: $--unnamed-color-fafafa 0% 0% no-repeat padding-box;
  border-radius: 20px;
  opacity: 1;
  .label {
    color: $--unnamed-color-000b1e;
    text-align: left;
    font-family:$Crimson_Pro;
    letter-spacing: 0px;
  }
  .text{
    margin-bottom: unset;
  }
  .adress,
  .text {
    font-family:$Helvetica_Neue_LT;
    color: $--unnamed-color-000000;
  }

  .adress {
    font-style: italic ;
  }
}



@media screen and (max-width: 767px) {

    .form {
      width: 367px;
      padding: 10px 20px;
    }
}
</style>
