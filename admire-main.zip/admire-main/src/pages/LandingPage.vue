<template>
  <div class="adminre-container-mid q-mx-auto">
    <div class="landing-head homeContainer q-mx-auto">
        <adm-title-h1 underline :titleText="$t('homeTitle1')" />
        <p class="desciprition text-center q-pt-md">
          {{ $t('homeDescription1') }}
        </p>
    </div>
    <div class="landing-body homeContainer q-mx-auto">
      <q-img class="img" src="../assets/images/admire.png" />
      <h2 class="title text-weight-bolder text-center">
        {{ $t('homeTitle2') }}
      </h2>

      <div class="row justify-center items-center">
        <q-btn size="28px" padding="lg" href="https://twitter.com/?lang=en" color="primary" flat round icon="fa-brands fa-twitter"/>
        <span class="v-square q-mx-md"></span>
        <q-btn size="28px" padding="lg" href="https://www.instagram.com/?hl=en" color="primary" flat round icon="fa-brands fa-instagram"/>
      </div>
      <div class="square"></div>
    </div>
    <subscribe-component />

  </div>
</template>

<script setup>
import SubscribeComponent from 'components/SubscribeComponent.vue'
import AdmTitleH1 from 'components/AdmTitleH1.vue';
</script>

<style lang="scss" scoped>
  .homeContainer {
    max-width: 613px;
  }
  .landing-head {
    .desciprition {
      color: $--unnamed-color-000000;
      font-family: $Crimson_Pro;
      font-size: 32px;
      line-height: 46px;
      font-weight: 500;
    }
  }

  .landing-body {
     margin-bottom: 70px;
    .title {
      color: $--unnamed-color-000000;
      font-family: $Crimson_Pro;
      font-size: 46px;
      line-height: 51px;
    }

    .icon {
      font-size: 50px;
      a {
        color: $--unnamed-color-000b1e;
      }
    }
    .square {
      width: 264px;
      height: 3px;
      margin: auto;
      margin-top: 150px;
      // margin-left: 120px;
      background: $--unnamed-color-777777 0% 0% no-repeat padding-box;
      opacity: 0.25;
    }

    .v-square {
      width: 3px;
      margin-top: 10px;
      height: 25px;
      background: $--unnamed-color-777777 0% 0% no-repeat padding-box;
      opacity: 0.25;
    }
  }


</style>
