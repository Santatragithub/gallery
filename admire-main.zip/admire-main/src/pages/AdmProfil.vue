<template>
  <div class="adminre-container-lg q-mx-auto">
    <div class="head-profil row justify-center">
        <q-img class="img q-ml-lg" src="https://placeimg.com/500/300/nature"/>
        <span class="icon-verif"><i class="fa-solid fa-check"></i></span>
        <div class="details">
          <p class="title text-weight-normal">Nomdelartiste</p>
          <p class="description">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br /> Proin ut felis orci.
            Etiam faucibus varius turpis in semper.<br /> Phasellus blandit nunc quis tellus ultrice.
          </p>
          <div class="row web">
            <p class="text-weight-bold">www.nomdelartiste.com</p>
            <div class="square q-mx-md"></div>
            <span><i class="fa-brands fa-twitter q-mr-sm"></i></span>
            <span><i class="fa-brands fa-instagram"></i></span>
          </div>
        </div>
    </div>
    <div class="line q-mt-xl"></div>
    <div class="tab row justify-center">
       <q-btn
          class="tabs"
          label="Created"
          @click="getList('Created')"
          :style="[filter=== 'Created' ? {'background': '#E8E8E8'}: {'background': '#FAFAFA'}]"
         />
       <q-btn
          class="tabs q-mx-xl"
          label="Owned"
          @click="getList('Owned')"
          :style="[filter=== 'Owned' ? {'background': '#E8E8E8'}: {'background': '#FAFAFA'}]"
        />
       <q-btn
          class="tabs"
          label="Selling"
          @click="getList('Selling')"
          :style="[filter=== 'Selling' ? {'background': '#E8E8E8'}: {'background': '#FAFAFA'}]"

        />
        <q-btn class="token" label="+ Create Token" color="secondary" @click="router.push('/')"/>
    </div>
    <div class="row justify-center">
      <q-btn-dropdown class="filter q-mx-md"  label="Artist">
        <q-list>
          <q-item clickable v-close-popup @click="onItemClick">
            <q-item-section>
              <q-item-label>Photos</q-item-label>
            </q-item-section>
          </q-item>
        </q-list>
      </q-btn-dropdown>
      <q-btn-dropdown class="filter q-mx-md" label="type">
        <q-list>
          <q-item clickable v-close-popup @click="onItemClick">
            <q-item-section>
              <q-item-label>Photos</q-item-label>
            </q-item-section>
          </q-item>
        </q-list>
      </q-btn-dropdown>
      <q-btn class="filter" label="Available for sale"/>
    </div>
    <div class="list row ">
       <div class=" q-ma-md" v-for="(item, index) in Item" :key="index" >
            <nft-item
              :url="item.url"
              :nftName = item.nftName
              :artistName = item.artistName
              :number = item.number
              :price = item.price
            />
       </div>

    </div>



  </div>
</template>
<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'

import NftItem from 'components/NftItem.vue'
import { Item } from '../data/constant/nftItem'

const router = useRouter()
const filter = ref('Created')


const getList = (_filter : string) => {
  filter.value = _filter
  console.log(filter.value)
}



// filter.value === 'Created' ? isActive = true

</script>
<style lang="scss" scoped>
.head-profil{

  .details {
    //margin-left: 15px;
    .title {
    font-family: $Poppins;
    font-size: 41px
    }
    .description {
      color: $--unnamed-color-000000;
      text-align: left;
      font-family: $Helvetica_Neue_LT;
      letter-spacing: 0px;
      overflow: hidden;
      font-size: 20px
    }
    .web {
      font-family: $Helvetica_Neue_LT;
      font-size: 20px
    }
    .square {
      width: 1px;
      height: 17px;
      background: $--unnamed-color-777777 0% 0% no-repeat padding-box;
      position: relative;
      top: 7px;
    }
  }
}
.img{
  margin-top: 15px;
  width: 202px;
  height:202px;
  border-radius: 50% ;
}
.icon-verif {
  background: $--unnamed-color-a967ae 0% 0% no-repeat padding-box;
  color: #fff;
  font-size: 40px;
  border-radius: 50%;
  width: 48px;
  height:48px;
  border: 2px solid #FFFFFF;
  position: relative;
  top: 145px;
  right: 40px;
  .fa-solid {
    position: absolute;
    left: 5px;
    top: 5px;
  }
}
.line {
  width: 1920px;
  height: 2px;
  background: #EFEFEF 0% 0% no-repeat padding-box;
  opacity: 1;
}
.tab {
  position: relative;
  bottom: 20px;
  margin-bottom: 25px;

  .tabs {
    //background: $--unnamed-color-fafafa !important;
    text-transform: none;
  }
  .token {
    background: $--unnamed-color-a967ae 0% 0% no-repeat padding-box !important;
    margin-left: 175px;
    text-transform: none;
  }
}

.filter {
  background: transparent !important;
  color: $--unnamed-color-777777 !important;
  font-family: $Crimson_Pro;
  font-size: 20px ;
  border: none !important;
  text-transform: none;


}
.q-btn.filter:before{
    box-shadow: none;
}
.q-btn.filter:deep(.q-icon:before) {
    font-size: 15px ;
}


.list {
  margin-left: 250px;
}
</style>
