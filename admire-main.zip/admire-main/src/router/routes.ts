import { RouteRecordRaw } from 'vue-router';

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    component: () => import('layouts/AdmireLayout.vue'),
    children: [
      {
        path: '/home',
        component: () => import('pages/LandingPage.vue'),
      },
      {
        path: '/faq',
        component: () => import('pages/FaqPage.vue'),
      },
      {
        path : '/sign-in',
        component: () => import('pages/SignInPage.vue'),
      },
      {
        path : '/sign-in-email',
        component: () => import('pages/SignInMail.vue'),
      },
      {
        path : '/sign-up',
        component: () => import('pages/SignUpPage.vue'),
      },
      {
        path : '/login',
        component: () => import('pages/LoginPage.vue'),
      },
      {
        path : '/profil',
        component: () => import('pages/AdmProfil.vue'),

      },
    ],
  },

  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/ErrorNotFound.vue'),
  },
];

export default routes;
