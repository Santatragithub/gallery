<template>
  <q-footer class="bg-white admireFooter q-pb-md-lg">
      <q-toolbar class="bg-white text-primary adminre-container-mid q-px-lg q-mx-auto w-100">
        <div class="full-width row no-wrap justify-between items-center ">
          <div class="footerBrand row no-wrap justify-center items-center content-center">
            <span class="date">2022 ©</span>
            <img class="q-ml-sm" src="../assets/images/Logo.svg" width="55.75"/>
          </div>
          <div class="footerLinks">
            <FooterLinksComponentVue v-if="$q.screen.gt.xs"/>
          </div>
        </div>
      </q-toolbar>
    </q-footer>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import FooterLinksComponentVue from './FooterLinksComponent.vue'

export default defineComponent({
  name: 'FooterComponent',
  components: {FooterLinksComponentVue}
})
</script>

<style lang="scss" scoped>
  .admireFooter {
    box-shadow: 0px 0px 35px rgba(0, 0, 0, 0.08);
    font: normal normal normal 16px/32px $Poppins;
  }
  .footerBrand {
    line-height: 13.28px;
    .date {
      padding-top: 2px;
    }
  }
</style>
