<template>
  <ul class="linkList items-center align-center q-my-none">
    <li class="item q-px-md"><q-btn to="/" color="primary" flat>{{ $t('Privacy_Policy') }}</q-btn></li>
    <li class="item q-px-md"><q-btn to="/faq" color="primary" flat>{{ $t('FAQ') }}</q-btn></li>
    <li class="item q-px-md"><q-btn color="primary" flat round icon="fa-brands fa-twitter"/><q-btn color="primary" flat round icon="fa-brands fa-instagram"/></li>
  </ul>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'FooterLinksComponent',
})
</script>

<style lang="scss" scoped>
  .linkList {
    display: flex;
    list-style-type: none;
    @media screen and (max-width: 992px) {
      flex-wrap: wrap;
      padding: 0px;
      .item {
        padding: 0;
        width: 100%;
        &:before {
          display: none;
        }
      }
    }
    .item {
      position: relative;
      &:before {
        background: $--unnamed-color-777777;
        content: '';
        height: 21.16px;
        opacity: 0.25;
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 1.5px;
      }
      &:last-child {
        &:before {
          display: none;
        }
      }
    }
    .q-btn {
      text-transform: none;
    }
  }
</style>
