<template>
  <h1 :class="`title ${ props.underline ? 'underlined' : '' }`" :style="`font-size:${props.size}`">{{ props.titleText }}</h1>
</template>

<script setup lang="ts">
import { defineProps, withDefaults } from 'vue';

interface TitleProps {
  titleText?: {
    type: string,
    required: true
  }
  underline: boolean,
  size: string
}
const props = withDefaults(defineProps<TitleProps>(), {
 size:'56px',
 underline:false,
})

// console.log('==> ', props)

</script>

<style lang="scss" scoped>
  .title {
    color: $--unnamed-color-000000;
    font-family: $Crimson_Pro;
    font-weight: bold;
    line-height: 68px;
  }
</style>
