<template>
  <q-drawer
      side="left"
      bordered
      :width="200"
      content-class="bg-grey-3"
      show-if-abov
    >
      <q-btn flat to="/" class="text-center q-pt-lg">
        <img src="../assets/images/Logo.svg" width="100"/>
      </q-btn>
      <q-separator spaced inset />
      <HeaderLinksComponent />
      <q-separator spaced inset />
      <FooterLinksComponent />
    </q-drawer>
</template>

<script setup lang="ts">
import HeaderLinksComponent from './HeaderLinksComponent.vue';
import FooterLinksComponent from './FooterLinksComponent.vue';

</script>

<style scoped>

</style>
