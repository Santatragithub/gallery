<template>
  <div class="item">
    <q-card class="my-card">
      <img class="img" :src="url">

      <q-card-section>
        <div class="text-h6">{{ nftName }}</div>
        <div class="text-subtitle2">{{ artistName}}</div>
        <div class="row justify-between">
          <div>{{ number}}</div>
          <div>{{ price }}ETH</div>
        </div>

      </q-card-section>

    </q-card>
  </div>
</template>
<script setup lang="ts">
import { defineProps, toRefs} from 'vue'
const props = defineProps<{
  url: string
  nftName: string
  artistName: string
  number: number
  price: string
}>()

const { url, nftName, artistName, number, price } = toRefs(props)

</script>
<style lang="scss" scoped>
.my-card {
  width: 100%;
  max-width: 250px;
  border-radius: 25px;
  .img{
     height: 300px;
  }
}
</style>
