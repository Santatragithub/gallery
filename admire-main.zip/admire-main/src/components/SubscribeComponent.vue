<template>
  <div class="subscribe q-mx-auto">
    <h2 class="title text-weight-bold text-center">{{ $t("subscribeTitle1") }}</h2>
    <div class="row justify-center no-wrap" >
      <q-input class="input q-pr-md" filled v-model="email"  placeholder="Enter email" :dense="true" />
      <q-btn size="18px" class="button" padding="17px 18px" color="black" type="email" @click="subscribe">{{ $t('subscribe') }}</q-btn>
    </div>
    <h3 class="description text-weight-bold  text-center">{{ $t("subscribeTitle2") }}</h3>
  </div>
</template>
<script setup lang="ts">
import { ref } from 'vue'

const email = ref('')

const subscribe = () => {
  console.log(email.value)
}

</script>
<style lang="scss" scoped>
.subscribe {
  max-width: 780px;
}
.title {
  font-family: $Crimson_Pro;
  font-size: 58px;
  letter-spacing: 0px;
  color: $--unnamed-color-000b1e;
  opacity: 1;
}

.description {
  color: $--unnamed-color-000b1e;
  font-family: $Helvetica_Neue_LT;
  font-size: 22px;
  letter-spacing: 0px;
  line-height: 32px;
  padding: 50px 0px 100px;
  text-align: center;
}

.input {
  color: #CECECE;
  font-family: $Helvetica_Neue_LT;
  font-size: 20px;
  width: 75%;
  :deep(.q-field__control) {
    height: 100%;
  }
  ::placeholder {
    color: #CECECE;
    font-weight: 300;
    opacity: 1;
  }

  :-ms-input-placeholder {
    font-weight: 300;
    color: #CECECE;
  }

  ::-ms-input-placeholder {
    font-weight: 300;
    color: #CECECE;
  }
}

.button {
  font-family: $Helvetica_Neue_LT;
  color: #FFF;
  max-width: 223px;
  width: 100%;
}
</style>

