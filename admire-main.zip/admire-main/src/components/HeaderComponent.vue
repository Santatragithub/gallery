<template>
  <q-header elevated class="bg-white adminreHeader-wrapper" height-hint="100">
      <q-toolbar height="100px">
        <div class="adminreHeader adminre-container-lg row wrap justify-between items-center q-mx-auto">
          <div class="headerBrand col-2 row items-center">
            <q-btn color="primary" round size="sm" icon="fa-solid fa-bars" v-if="!$q.screen.gt.sm" @click='$emit("toggleDrawer")'/>
            <q-btn flat to="/" v-if="$q.screen.gt.sm">
              <img src="../assets/images/Logo.svg" width="165.17"/>
            </q-btn>
          </div>
          <div class="col">
            <div class="full-width row wrap justify-center items-center">
              <HeaderLinksComponent v-if="$q.screen.gt.sm" />
              <q-input dense rounded outlined v-model="search" class="admireSearch q-ml-lg ">
                <template v-slot:prepend>
                  <q-icon name="fa-solid fa-magnifying-glass" size="12px"/>
                </template>
              </q-input>
            </div>
            </div>
          <div class="col-3 text-right">
            <q-btn class="admireBtnHeader" to="/" color="primary" no-shadow size="20px" padding="9px 40px" v-if="$q.screen.gt.sm">{{ $t('Sign_in_or_Register')}}</q-btn>
            <q-btn to="/" color="primary" round size="12px" icon="fa-solid fa-user" v-if="!$q.screen.gt.sm"/>
          </div>
        </div>
      </q-toolbar>
    </q-header>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import HeaderLinksComponent from './HeaderLinksComponent.vue'

export default defineComponent({
  name: 'HeaderComponent',
  components: {HeaderLinksComponent},
  setup() {
    return {
      search: ref(''),
    }
  }
})
</script>

<style lang="scss" scoped>
  .adminreHeader-wrapper {
    box-shadow: 0px 0px 35px #F5F5F5;
  }
  .adminreHeader {
    font: normal normal 600 24px/27px $Crimson_Pro;
    height: 100px;
    width: 100%;
    @media screen and (max-width: 992px) {
      height: 50px;
    }
  }
  :deep(.q-layout__shadow) {
      display: none;
    }
  .admireSearch {
    font-family: $Helvetica_Neue_LT;
    max-width: 350px;
    width: 100%;
    :deep(.q-field__control), :deep(.q-field__marginal){
      height: 23px;
    }
    :deep(.q-field__control:before) {
      background: #E9E9E9;
      border: none;
    }
  }
  .admireBtnHeader {
    font: normal 21px/27px $Helvetica_Neue_LT;
    text-transform: none;    ;
  }
</style>
