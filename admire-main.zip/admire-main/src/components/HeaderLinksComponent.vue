<template>
  <ul class="linkList items-center align-start q-my-none q-pa-none">
    <li class="item"><q-btn to="/" color="primary" flat>{{ $t('Store') }}</q-btn></li>
    <li class="item"><q-btn to="/faq" color="primary" flat>{{ $t('Collection') }}</q-btn></li>
    <li class="item"><q-btn to="/faq" color="primary" flat>{{ $t('Gallery') }}</q-btn></li>
  </ul>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'HeaderLinksComponent',
})
</script>

<style lang="scss" scoped>
  .linkList {
    display: flex;
    @media screen and (max-width: 992px) {
      flex-wrap: wrap;
      .item {
        width: 100%;
      }
    }
    .item {
      list-style-type: none;
    }
    :deep(.q-btn) {
      font: 25px/27px $Crimson_Pro;
      text-transform: none;
      @media screen and (max-width: 992px) {
        font-size: 18px;
      }
    }
  }
</style>
