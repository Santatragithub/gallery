<template>
  <q-btn class="button" color="primary" >
      {{ textButton }}
  </q-btn>
</template>
<script setup lang="ts">
import { defineProps, toRefs} from 'vue'
const props = defineProps<{
  textButton: boolean
}>()

const { textButton } = toRefs(props)
</script>

<style lang="scss" scoped>
.button {
  width: 150px;
}

.q-btn.button:deep(.q-btn__content) {
    color: #fff;
    text-align: center;
    font-family: $Helvetica_Neue_LT;
    font-weight: 500;
  }

</style>
