// This is just an example,
// so you can safely delete all default props below

export default {
  failed: 'Failed',
  success: 'Action was successful',
  Privacy_Policy: 'Privacy Policy',
  FAQ: 'FAQ',
  Sign_in_or_Register: 'Sign in or Register',
  homeTitle1:
    'Honestly now, don’t you want to finally be able to collect masters’ #nfts?',
  homeDescription1:
    'Well, there is only one way to own valuable artworks: by collecting on admire. At admire, we work with the most prestigious galleries to give users the ability to collect artworks from the world’s most famous and valuable artists.',
  homeTitle2: 'LAUNCHING SUMMER 2022',
  subscribeTitle1: "Don't miss the launch",
  subscribeTitle2: 'MINTED BY ARTISTS, SOLD BY GALLERIES, COLLECTED BY YOU',
  subscribed: 'Subscribe',
};
